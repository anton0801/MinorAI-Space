// Language: ?lang=ru|en, then the visitor's saved choice, then the browser language.
(function () {
  var root = document.documentElement;
  function stored() {
    try { return localStorage.getItem("minor-lang"); } catch (e) { return null; }
  }
  function save(lang) {
    try { localStorage.setItem("minor-lang", lang); } catch (e) { /* private mode */ }
  }
  function apply(lang) {
    root.setAttribute("data-lang", lang);
    root.setAttribute("lang", lang);
    var buttons = document.querySelectorAll("[data-set-lang]");
    for (var i = 0; i < buttons.length; i++) {
      buttons[i].setAttribute("aria-pressed", String(buttons[i].getAttribute("data-set-lang") === lang));
    }
    var title = root.getAttribute("data-title-" + lang);
    if (title) document.title = title;
  }
  var query = (location.search.match(/[?&]lang=(en|ru)/) || [])[1];
  var browser = (navigator.language || "en").toLowerCase().indexOf("ru") === 0 ? "ru" : "en";
  apply(query || stored() || browser);

  document.addEventListener("click", function (event) {
    var button = event.target.closest && event.target.closest("[data-set-lang]");
    if (!button) return;
    var lang = button.getAttribute("data-set-lang");
    save(lang);
    apply(lang);
  });

  var year = document.querySelectorAll("[data-year]");
  for (var j = 0; j < year.length; j++) year[j].textContent = String(new Date().getFullYear());
})();
